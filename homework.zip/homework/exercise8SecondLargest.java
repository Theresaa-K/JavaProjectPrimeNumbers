package homework;

public class exercise8SecondLargest {
    public static void main(String[] args) {
        int[] numbers = {10, 20 , 4, 45, 99};
        int first = Integer.MIN_VALUE;
        int second = Integer.MIN_VALUE;

        for ( int num : numbers ) {
            if (num >first ) {
                second = first;
                first= num;

            }else if
                (num>second && num != first){
                second = num;
            }

        }
        System.out.println("Second largest number: " + second);
    }
}
