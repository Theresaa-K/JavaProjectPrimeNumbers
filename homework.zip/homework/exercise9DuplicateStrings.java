package homework;

import java.util.HashSet;

public class exercise9DuplicateStrings {
    public static void main(String[] args) {

        String[] words = {"apple", "banana", "apple", "orange", "banana", "grape"};
        HashSet<String> uniqueWords = new HashSet<>();
        HashSet<String> duplicates = new HashSet<>();
        for (String word : words){
            if (!uniqueWords.add(word)) {
                duplicates.add(word);
            }
        }
        System.out.println("Duplicate elements: " + duplicates);
    }
}
