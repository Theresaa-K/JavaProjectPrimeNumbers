package homework;

public class exercise7FibonacciSeries {
    public static void main(String[] args) {
        int n1 = 0, n2 = 1;

        System.out.println("Fibonacci series: " +n1 + " " + n2 + " ");

        for(int i = 3; i<= 10; i++){
            int n3 = n1 + n2;
            System.out.println(n3 + " ");
            n1 = n2;
            n2 = n3;
        }
    }
}
