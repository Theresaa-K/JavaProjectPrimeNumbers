package homework;

import java.util.HashSet;

public class exercise1Temperature {
    public static void main(String[] args) {

        int []temperatures = { 72, 75, 78, 71, 68, 69, 74 };

                int max= temperatures[0];
                int min= temperatures[0];

                for (int temp : temperatures) {
                    if (temp>max) max = temp;
                    if(temp<min) min = temp;

                }
        System.out.println("Highest temperature: "+ max);
        System.out.println("Lowest temperature: "+ min);


    }

    public static class exercise3EvenNumbers2D {
        public static void main(String[] args) {
            int[][] numbers = {{1, 2, 3},{4, 5, 6}, {7, 8, 9}};

            System.out.println("Even numbers in the array:");
            for(int[] row : numbers) {
                for(int num : row ){
                    if (num % 2 == 0){
                        System.out.println(num + " ");
                    }
                }
            }
        }
    }

    public static class exercise8DuplicateStrings {
        public static void main(String[] args) {
            String[] words = {"apple" , "banana", "apple", "orange", "banana","grape"};
            HashSet<String> uniqueWords = new HashSet<>();
            HashSet<String> duplicates = new HashSet<>();

            for (String word : words ){
                if(!uniqueWords.add(word)) {
                    duplicates.add(word);
                }
            }
            System.out.println("Duplicate elements : " + duplicates);
        }
    }
}
